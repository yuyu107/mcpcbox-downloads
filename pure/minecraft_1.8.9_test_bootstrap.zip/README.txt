MCPCBox Minecraft 1.8.9 test bootstrap.
No Minecraft client or Mojang assets are bundled.
